#define STB_TEST_IMPLEMENTATION
#include <stb_test.h>
