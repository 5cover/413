#ifndef TESTS_H
#define TESTS_H

#include <stb_test.h>

struct test test_uuid4(void);

void observe_put_role(void);

#endif // TESTS_H
